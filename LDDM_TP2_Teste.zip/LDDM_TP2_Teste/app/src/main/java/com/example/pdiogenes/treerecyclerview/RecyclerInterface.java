package com.example.pdiogenes.treerecyclerview;

public interface RecyclerInterface {
    void onItemClick (Object object);
}
