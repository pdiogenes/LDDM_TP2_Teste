# TP #2 LDDM  
PUC-MG 04/2019  
Prof. Humberto  

### Progress
- [x] Basic Layout
- [x] Recycler View
- [x] Nested Recycler View
- [x] Tree data structure
- [ ] Return to parent recycler view function
- [ ] Database implementation
